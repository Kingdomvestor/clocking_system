-- =============================================
-- clocking_system
-- v2: Admin-Only Architecture
-- =============================================

CREATE DATABASE IF NOT EXISTS clocking_system
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE clocking_system;

-- Staff table (no passwords — admin manages everything)
CREATE TABLE IF NOT EXISTS employee (
    id            INT           PRIMARY KEY AUTO_INCREMENT,
    staff_id      VARCHAR(20)   UNIQUE NOT NULL,
    full_name     VARCHAR(100)  NOT NULL,
    department    VARCHAR(50)   NOT NULL,
    designation   VARCHAR(50)   NOT NULL,
    email         VARCHAR(100)  UNIQUE NOT NULL,
    phone         VARCHAR(20)   NULL,
    enroll_date   DATE          NOT NULL,
    is_active     TINYINT(1)    DEFAULT 1,
    created_at    TIMESTAMP     DEFAULT CURRENT_TIMESTAMP
);

-- Attendance table
CREATE TABLE IF NOT EXISTS attendance (
    id               INT           PRIMARY KEY AUTO_INCREMENT,
    staff_id         VARCHAR(20)   NOT NULL,
    clock_in         DATETIME      NOT NULL,
    clock_out        DATETIME      NULL,
    att_date         DATE          NOT NULL,
    hours_worked     DECIMAL(5,2)  NULL,
    auto_clocked_out TINYINT(1)    DEFAULT 0,
    notes            VARCHAR(255)  NULL,
    created_at       TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (staff_id) REFERENCES employee(staff_id) ON DELETE CASCADE,
    UNIQUE KEY unique_daily (staff_id, att_date)
);

-- QR tokens (admin-generated, short-lived)
-- action: clock_in | clock_out | register
CREATE TABLE IF NOT EXISTS qr_tokens (
    id         INT         PRIMARY KEY AUTO_INCREMENT,
    token      VARCHAR(64) UNIQUE NOT NULL,
    staff_id   VARCHAR(20) NOT NULL,
    action     ENUM('clock_in','clock_out','register') NOT NULL,
    expires_at DATETIME    NOT NULL,
    used       TINYINT(1)  DEFAULT 0,
    created_at TIMESTAMP   DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (staff_id) REFERENCES employee(staff_id) ON DELETE CASCADE
);

-- WebAuthn credentials (fingerprint per staff, per device)
CREATE TABLE IF NOT EXISTS webauthn_credentials (
    id            INT         PRIMARY KEY AUTO_INCREMENT,
    staff_id      VARCHAR(20) NOT NULL,
    credential_id TEXT        NOT NULL,
    public_key    TEXT        NOT NULL,
    sign_count    INT         DEFAULT 0,
    created_at    TIMESTAMP   DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (staff_id) REFERENCES employee(staff_id) ON DELETE CASCADE
);

-- Admin account (single admin)
CREATE TABLE IF NOT EXISTS admin (
    id            INT          PRIMARY KEY AUTO_INCREMENT,
    username      VARCHAR(50)  UNIQUE NOT NULL,
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    last_login    DATETIME     NULL,
    created_at    TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- =============================================
-- Seed Data
-- =============================================

-- Default admin (password stored plain-text per system design: Admin@1234)
INSERT IGNORE INTO admin (username, full_name, email, password_hash)
VALUES ('admin', 'System Administrator', 'admin@Soteria Business School.com', 'Admin@1234');

-- Sample staff
INSERT IGNORE INTO employee (staff_id, full_name, department, designation, email, enroll_date)
VALUES
    ('HAL-001', 'John Doe',     'Technical/Engineering', 'Senior Engineer',  'john.doe@Soteria Business School.com',   CURDATE()),
    ('HAL-002', 'Jane Smith',   'Administration',        'Office Manager',   'jane.smith@Soteria Business School.com', CURDATE()),
    ('HAL-003', 'Emeka Okafor', 'Operations',            'Field Supervisor', 'emeka.o@Soteria Business School.com',    CURDATE());

SELECT 'Setup complete — Admin login: admin / Admin@1234' AS status;
